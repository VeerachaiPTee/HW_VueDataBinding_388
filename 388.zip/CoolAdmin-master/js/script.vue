   //navbar
var app = new Vue({
  el: '#my-logo',
  data: {
    message: 'My Dashboard'
  }
})
var app = new Vue({
  el: '#myname',
  data: {
    message: 'Veerachai Seangkom'
  }
})
var app = new Vue({
  el: '#myname-nav',
  data: {
    message: 'Veerachai Seangkom'
  }
})
var app = new Vue({
  el: '#myemail-nav',
  data: {
    message: 'Devtee.pp@gmail.com'
  }
})


//skillchart
var app = new Vue({
  el: '#skillitem-1',
  data: {
    message: 'HTML'
  }
})
var app = new Vue({
  el: '#skillitem-2',
  data: {
    message: 'CSS'
  }
})
var app = new Vue({
  el: '#skillitem-3',
  data: {
    message: 'VueJS'
  }
})
var app = new Vue({
  el: '#chartname',
  data: {
    message: 'Chart Skill coding by %'
  }
})

// overview

var app = new Vue({
  el: '#Facultyname',
  data: {
    message: 'Com-Sci'
  }
})
var app = new Vue({
  el: '#myclass',
  data: {
    message: 'Maejo University'
  }
})
var app = new Vue({
  el: '#total-cost',
  data: {
    message: '200$'
  }
})
var app = new Vue({
  el: '#namecost',
  data: {
    message: 'Total cost in 2021'
  }
})
var app = new Vue({
  el: '#number-location',
  data: {
    message: '29 location'
  }
})
var app = new Vue({
  el: '#plantravel',
  data: {
    message: 'Travel 20 location in 2021'
  }
})
var app = new Vue({
  el: '#mymoney',
  data: {
    message: 'My money in 2021'
  }
})

//profile

var app = new Vue({
  el: '#profileme',
  data: {
    message: 'My profile'
  }
})
var app = new Vue({
  el: '#profileitem1',
  data: {
    message: 'Name : '
  }
})
var app = new Vue({
  el: '#profileitem2',
  data: {
    message: 'Veerachai Seangkom'
  }
})
var app = new Vue({
  el: '#profileitem3',
  data: {
    message: 'Education : '
  }
})
var app = new Vue({
  el: '#profileitem4',
  data: {
    message: 'University'
  }
})
var app = new Vue({
  el: '#profileitem5',
  data: {
    message: 'My hobby'
  }
})
var app = new Vue({
  el: '#profileitem6',
  data: {
    todos: [
      { text: 'Work' },
      { text: 'Homework' },
      { text: 'Play game' }
    ]
  }
})
var app = new Vue({
  el: '#profileitem7',
  data: {
    message: 'Country'
  }
})
var app = new Vue({
  el: '#profileitem8',
  data: {
    todos: [
      { text: 'Thailand' }
    ]
  }
})

//to do list

var app = new Vue({
  el: '#todoheader',
  data: {
    message: 'To do lists'
  }
})
var app = new Vue({
  el: '#todo1',
  data: {
    message: 'Day'
  }
})
var app = new Vue({
  el: '#todo2',
  data: {
    message: 'Time'
  }
})
var app = new Vue({
  el: '#todo3',
  data: {
    message: 'Title'
  }
})

var app = new Vue({
  el: '#monday',
  data: {
    message: 'Monday'
  }
})
var app = new Vue({
  el: '#times1',
  data: {
    message: '08:00 AM'
  }
})
var app = new Vue({
  el: '#titleitem1',
  data: {
    message: 'learning',
  }
})
var app = new Vue({
  el: '#mainapp-1',
  data: {
    Tuesday: 'Tuesday',
    Wednesday: 'Wednesday',
    Thursday: 'Thursday',
    friday:  'Friday',
    Saturday: 'Saturday',
    sunday: 'Sunday',
    time: '08.00 AM',
    learning: 'learning',
    working: 'working'
  }
})

var app = new Vue({
  el: '#app_3',
  data:{
    dayforeven: '31 December 2021',
    taskme: 'Task for me',
    meeting: 'Hangout with my friend',
    time: '08:00 AM',
    travel: 'Travel in Chiang Mai',
    time2: '11:00 AM',
    party: 'Party with my friend',
    time3: '08:00 PM',
    sleep: 'Sleep',
    time4: '10:00 PM'
  }
})

var app = new Vue({
  el: '#app_4',
  data: {
  friend: 'Friend list',
  fri1: 'James Maneewan',
  email_1: 'James@mju.com',
  fri2: 'Boy Santiphap',
  email_2: 'Boy@mju.com',
  fri3: 'Winner Pittaya',
  email_3: 'Winner@mju.com',
  fri4: 'First Supawit',
  email_4: 'First@mju.com'


  }
})


